import { FormEvent, ReactNode, useMemo, useState } from 'react'

type Page =
  | 'discover'
  | 'conversation'
  | 'conversations'
  | 'spaces'
  | 'jobs'
  | 'documents'
  | 'data'
  | 'connections'
  | 'reports'
  | 'status'
  | 'alerts'

type IconName =
  | 'spark'
  | 'plus'
  | 'chat'
  | 'grid'
  | 'clock'
  | 'upload'
  | 'database'
  | 'link'
  | 'chart'
  | 'pulse'
  | 'bell'
  | 'help'
  | 'settings'
  | 'menu'
  | 'search'
  | 'send'
  | 'paperclip'
  | 'mic'
  | 'chevron'
  | 'arrow'
  | 'file'
  | 'check'
  | 'warning'
  | 'more'
  | 'filter'
  | 'download'
  | 'refresh'
  | 'close'
  | 'play'
  | 'pause'
  | 'calendar'
  | 'external'
  | 'eye'

const paths: Record<IconName, ReactNode> = {
  spark: <><path d="m12 3-1.1 3.2a7 7 0 0 1-4.7 4.7L3 12l3.2 1.1a7 7 0 0 1 4.7 4.7L12 21l1.1-3.2a7 7 0 0 1 4.7-4.7L21 12l-3.2-1.1a7 7 0 0 1-4.7-4.7Z"/><path d="M5 3v4M3 5h4M19 17v4M17 19h4"/></>,
  plus: <path d="M12 5v14M5 12h14"/>,
  chat: <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/>,
  grid: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
  clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
  upload: <><path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 15v5h16v-5"/></>,
  database: <><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7"/></>,
  link: <><path d="M10 13a5 5 0 0 0 7.5.5l2-2a5 5 0 0 0-7-7l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.5-.5l-2 2a5 5 0 0 0 7 7l1.1-1.1"/></>,
  chart: <><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></>,
  pulse: <path d="M3 12h4l2-7 4 14 2-7h6"/>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
  help: <><circle cx="12" cy="12" r="9"/><path d="M9.8 9a2.5 2.5 0 1 1 3.4 2.3c-.8.4-1.2.9-1.2 1.7M12 17h.01"/></>,
  settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1a1.7 1.7 0 0 0 1.9.3 1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z"/></>,
  menu: <path d="M4 7h16M4 12h16M4 17h16"/>,
  search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
  send: <path d="m22 2-7 20-4-9-9-4Z M22 2 11 13"/>,
  paperclip: <path d="m21.4 11.6-8.9 8.9a6 6 0 0 1-8.5-8.5l9.6-9.6a4 4 0 0 1 5.7 5.7l-9.6 9.6a2 2 0 0 1-2.8-2.8l8.9-8.9"/>,
  mic: <><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/></>,
  chevron: <path d="m9 18 6-6-6-6"/>,
  arrow: <path d="M5 12h14m-5-5 5 5-5 5"/>,
  file: <><path d="M6 2h8l4 4v16H6Z"/><path d="M14 2v5h5M9 13h6M9 17h6"/></>,
  check: <path d="m5 12 4 4L19 6"/>,
  warning: <><path d="M12 3 2.5 20h19Z"/><path d="M12 9v4M12 17h.01"/></>,
  more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
  filter: <path d="M3 5h18l-7 8v5l-4 2v-7Z"/>,
  download: <><path d="M12 3v12m-5-5 5 5 5-5"/><path d="M4 19v2h16v-2"/></>,
  refresh: <><path d="M20 7h-5V2"/><path d="M20 7a9 9 0 1 0 1 7"/></>,
  close: <path d="m6 6 12 12M18 6 6 18"/>,
  play: <path d="m8 5 11 7-11 7Z"/>,
  pause: <path d="M9 5v14M15 5v14"/>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M8 3v4M16 3v4M3 10h18"/></>,
  external: <><path d="M14 4h6v6M20 4l-9 9"/><path d="M19 14v5H5V5h5"/></>,
  eye: <><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></>,
}

function Icon({ name, size = 18 }: { name: IconName; size?: number }) {
  return <svg className="icon" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>
}

function Button({ children, icon, variant = 'secondary', onClick, className = '', title, type = 'button' }: { children?: ReactNode; icon?: IconName; variant?: 'primary' | 'secondary' | 'ghost' | 'icon' | 'danger'; onClick?: () => void; className?: string; title?: string; type?: 'button' | 'submit' }) {
  return <button type={type} title={title} onClick={onClick} className={`btn btn-${variant} ${className}`}>{icon && <Icon name={icon} />}{children}</button>
}

function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`input ${props.className || ''}`} />
}

function Select({ value, onChange, children, className = '' }: { value?: string; onChange?: (value: string) => void; children: ReactNode; className?: string }) {
  return <select value={value} onChange={(event) => onChange?.(event.target.value)} className={`select ${className}`}>{children}</select>
}

function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={`textarea ${props.className || ''}`} />
}

const navGroups: { label: string; items: { id: Page; label: string; icon: IconName }[] }[] = [
  { label: 'Primary', items: [
    { id: 'discover', label: 'Discover', icon: 'spark' },
    { id: 'conversation', label: 'New conversation', icon: 'plus' },
    { id: 'conversations', label: 'Conversations', icon: 'chat' },
    { id: 'spaces', label: 'Spaces', icon: 'grid' },
    { id: 'jobs', label: 'Jobs', icon: 'clock' },
  ] },
  { label: 'Business data', items: [
    { id: 'documents', label: 'Document ingestion', icon: 'upload' },
    { id: 'data', label: 'Database explorer', icon: 'database' },
    { id: 'connections', label: 'DB connections', icon: 'link' },
    { id: 'reports', label: 'Tender reports', icon: 'chart' },
  ] },
  { label: 'Operations', items: [
    { id: 'status', label: 'System status', icon: 'pulse' },
    { id: 'alerts', label: 'Alerts', icon: 'bell' },
  ] },
]

const prompts = [
  'Which government tenders should we prioritize this month?',
  'Summarize all open tenders closing in the next 30 days.',
  'Compare distributor sales in New Zealand and Australia.',
  'Which Smartstud products have the highest sales growth?',
  'Find quotations waiting for approval.',
  'Prepare a tender opportunity brief for Auckland.',
]

const tenders = [
  { id: 'TND-2026-001', name: 'Auckland Smart Road Upgrade', agency: 'NZ Transport Agency', country: 'New Zealand', date: '24 Nov 2026', value: 'NZD 1,250,000', product: 'Smartstud', status: 'Submitted' },
  { id: 'TND-2026-002', name: 'Wellington Tunnel Safety Upgrade', agency: 'Wellington Infrastructure', country: 'New Zealand', date: '03 Dec 2026', value: 'NZD 840,000', product: 'Tunnel markers', status: 'Pending' },
  { id: 'TND-2026-003', name: 'Christchurch Pedestrian Safety', agency: 'Christchurch City Council', country: 'New Zealand', date: '15 Dec 2026', value: 'NZD 420,000', product: 'Smartped', status: 'Identified' },
  { id: 'TND-2026-004', name: 'Brisbane Active Crossing Program', agency: 'Brisbane City Council', country: 'Australia', date: '08 Jan 2027', value: 'AUD 690,000', product: 'Smartped', status: 'Won' },
  { id: 'TND-2026-005', name: 'Oslo Winter Road Visibility', agency: 'Norwegian Roads Authority', country: 'Norway', date: '19 Jan 2027', value: 'EUR 580,000', product: 'Smartstud', status: 'Pending' },
  { id: 'TND-2026-006', name: 'Singapore Tunnel Guidance', agency: 'Land Transport Authority', country: 'Singapore', date: '28 Jan 2027', value: 'SGD 1,100,000', product: 'Tunnel markers', status: 'Submitted' },
]

function Status({ children, tone = 'blue' }: { children: ReactNode; tone?: 'blue' | 'green' | 'amber' | 'red' | 'gray' }) {
  return <span className={`status status-${tone}`}><span className="status-dot" />{children}</span>
}

function PageHeader({ title, subtitle, action }: { title: string; subtitle: string; action?: ReactNode }) {
  return <div className="page-header"><div><div className="eyebrow">Street Smart Cockpit</div><div className="page-title">{title}</div><div className="page-subtitle">{subtitle}</div></div>{action}</div>
}

function Composer({ value, setValue, onSend, compact = false }: { value: string; setValue: (v: string) => void; onSend: () => void; compact?: boolean }) {
  return <form className={`composer ${compact ? 'composer-compact' : ''}`} onSubmit={(event) => { event.preventDefault(); onSend() }}>
    <Textarea value={value} onChange={(e) => setValue(e.target.value)} placeholder="Ask Street Smart anything about your business..." rows={compact ? 1 : 2} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); onSend() } }} />
    <div className="composer-toolbar">
      <div className="composer-tools">
        <Button icon="paperclip" variant="icon" title="Attach a document" onClick={() => setValue(`${value}${value ? ' ' : ''}[Document attached]`)} />
        <Button icon="mic" variant="icon" title="Voice input" onClick={() => setValue('Show me the highest priority tender opportunities')} />
        <Select aria-label="Business context"><option>All business data</option><option>Tenders</option><option>Distributor sales</option><option>Product catalogue</option><option>Documents</option></Select>
      </div>
      <Button icon="send" variant="primary" type="submit">Send</Button>
    </div>
  </form>
}

function Discover({ openConversation }: { openConversation: (prompt: string) => void; go: (page: Page) => void }) {
  const [prompt, setPrompt] = useState('')
  return <div className="discover page-scroll">
    <div className="hero">
      <div className="ai-mark"><Icon name="spark" size={24} /></div>
      <div className="hero-title">What can I help you with?</div>
      <div className="hero-subtitle">Ask about tenders, sales, products, quotations, or operations.</div>
      <Composer value={prompt} setValue={setPrompt} onSend={() => prompt.trim() && openConversation(prompt)} />
      <div className="prompt-grid">
        {prompts.slice(0, 3).map((item) => <button className="prompt-chip" key={item} onClick={() => openConversation(item)}><span>{item}</span><Icon name="arrow" size={15} /></button>)}
      </div>
      <div className="hero-footnote"><span /> Using simulated Street Smart business data</div>
    </div>
  </div>
}

function Conversation({ initialPrompt, go, toast }: { initialPrompt: string; go: (page: Page) => void; toast: (text: string) => void }) {
  const [prompt, setPrompt] = useState('')
  const [question, setQuestion] = useState(initialPrompt || prompts[0])
  const [thinking, setThinking] = useState(false)
  const [sources, setSources] = useState(false)
  const send = () => {
    if (!prompt.trim()) return
    setThinking(true)
    const next = prompt
    setPrompt('')
    window.setTimeout(() => { setQuestion(next); setThinking(false) }, 700)
  }
  return <div className="conversation-shell">
    <div className="conversation-header"><div><div className="conversation-title">New Zealand tender priorities</div><div className="conversation-meta">Tender Intelligence Agent · Updated just now</div></div><div className="header-actions"><Button icon="grid" onClick={() => toast('Conversation saved to Tender Opportunity Review')}>Save to Space</Button><Button icon="more" variant="icon" title="More actions" onClick={() => toast('Conversation options opened')} /></div></div>
    <div className="conversation-feed">
      <div className="message-user"><div className="user-avatar">IN</div><div><div className="message-label">You</div><div className="user-bubble">{question}</div></div></div>
      {thinking ? <div className="thinking-card"><div className="ai-mark small"><Icon name="spark" /></div><div><div className="thinking-title">Analyzing your business data</div><div className="thinking-steps"><span className="done"><Icon name="check" size={14} />Searching tender database</span><span className="active"><span className="spinner" />Comparing product capabilities</span><span>Preparing recommendation</span></div></div></div> :
      <div className="message-ai">
        <div className="ai-mark small"><Icon name="spark" /></div>
        <div className="ai-response">
          <div className="message-label">Street Smart AI <span className="agent-pill">Tender Intelligence Agent</span></div>
          <div className="answer-title">Three opportunities stand out</div>
          <div className="answer-copy">Based on estimated value, product fit, deadline proximity, and submission readiness, I recommend prioritizing these New Zealand opportunities.</div>
          <div className="tender-cards">
            {tenders.slice(0, 3).map((tender, index) => <div className="tender-card" key={tender.id}><div className="tender-rank">0{index + 1}</div><div className="tender-top"><div><div className="tender-name">{tender.name}</div><div className="tender-agency">{tender.agency}</div></div><Status tone={index < 2 ? 'amber' : 'gray'}>{index < 2 ? 'High priority' : 'Medium'}</Status></div><div className="tender-stats"><div><span>Estimated value</span><strong>{tender.value}</strong></div><div><span>Closes</span><strong>{tender.date}</strong></div><div><span>Product fit</span><strong>{tender.product}</strong></div></div><Button variant="ghost" onClick={() => go('data')}>View opportunity <Icon name="arrow" size={15} /></Button></div>)}
          </div>
          <div className="recommendation"><div className="recommendation-icon"><Icon name="spark" /></div><div><div className="recommendation-title">AI recommendation</div><div>Prioritize Auckland first because of its higher value and strong fit with the current Smartstud range. Begin technical compliance checks for Wellington in parallel.</div></div></div>
          <div className="action-row"><Button variant="primary" onClick={() => go('data')}>Open tender pipeline</Button><Button onClick={() => toast('Comparison workspace prepared')}>Compare opportunities</Button><Button onClick={() => toast('Tender brief generated and saved')}>Prepare tender brief</Button></div>
          <div className="sources">
            <button className="sources-toggle" onClick={() => setSources(!sources)}><Icon name="file" size={16} />Sources · 3 references<Icon name="chevron" size={16} /></button>
            {sources && <div className="sources-list"><div>NZTA_Tender_2026.pdf <span>Page 4</span></div><div>Tender Pipeline / TND-2026-001 <span>Updated today</span></div><div>Product Catalogue / Smartstud <span>Version 3.4</span></div></div>}
          </div>
          <div className="followups"><div className="followup-label">Suggested follow-ups</div>{['Compare the technical requirements', 'Show deadlines on a timeline', 'Prepare a tender response checklist'].map((item) => <Button key={item} variant="secondary" onClick={() => { setPrompt(item); }}>{item}</Button>)}</div>
        </div>
      </div>}
    </div>
    <div className="conversation-composer"><Composer value={prompt} setValue={setPrompt} onSend={send} compact /><div className="disclaimer">AI responses use simulated company data and may contain errors. Verify consequential decisions.</div></div>
  </div>
}

function Spaces({ toast }: { toast: (text: string) => void }) {
  const cards = [
    ['Tender Opportunity Review', 'Review and prioritize active government tenders.', '12 records', '4 conversations', 'amber'],
    ['Distributor Performance', 'Analyze sales by region, product, and quarter.', '8 reports', '3 conversations', 'blue'],
    ['Product Portfolio Intelligence', 'Explore catalogue, pricing, and sales trends.', '64 products', '6 insights', 'green'],
    ['Government Tender Response', 'Organize requirements, compliance, and tasks.', '9 tasks', '5 documents', 'purple'],
  ]
  return <div className="content-page page-scroll"><PageHeader title="Spaces" subtitle="Persistent workspaces organized around your business goals." action={<Button icon="plus" variant="primary" onClick={() => toast('New Space created')}>Create Space</Button>} /><div className="space-grid">{cards.map(([name, desc, stat, meta, tone]) => <button className="space-card" key={name} onClick={() => toast(`${name} workspace opened`)}><div className={`space-art ${tone}`}><Icon name={name.includes('Tender') ? 'file' : name.includes('Distributor') ? 'chart' : name.includes('Product') ? 'grid' : 'check'} size={24} /></div><div className="space-body"><div className="space-title">{name}</div><div className="space-desc">{desc}</div><div className="space-stats"><span>{stat}</span><span>{meta}</span></div><div className="space-footer"><div className="avatar-stack"><span>IN</span><span>SM</span><span>+2</span></div><Icon name="arrow" /></div></div></button>)}</div></div>
}

function Jobs({ toast }: { toast: (text: string) => void }) {
  const jobs = [
    ['Tender Document Extraction', 'Document Intelligence Agent', 'Running', 'PDF upload', '2 min ago', '68%'],
    ['Distributor Sales Import', 'Distributor Sales Agent', 'Completed', 'New file', '35 min ago', '100%'],
    ['Quotation Classification', 'Product & Quotation Agent', 'Running', 'Inbox item', '8 min ago', '42%'],
    ['Tender Deadline Monitoring', 'Tender Intelligence Agent', 'Active', 'Every 6 hours', '3 hours ago', '—'],
    ['Weekly Sales Summary', 'Distributor Sales Agent', 'Scheduled', 'Monday, 8:00 AM', 'Yesterday', '—'],
  ]
  return <div className="content-page page-scroll"><PageHeader title="Jobs & automations" subtitle="AI agents working across your operational workflows." action={<Button icon="plus" variant="primary" onClick={() => toast('Job builder opened')}>Create job</Button>} /><div className="summary-row"><div className="summary-card"><span>Active jobs</span><strong>5</strong><small>Across 4 agents</small></div><div className="summary-card"><span>Completed today</span><strong>2</strong><small>100% successful</small></div><div className="summary-card"><span>Awaiting review</span><strong>1</strong><small>Human approval required</small></div></div><div className="table-card"><div className="table-toolbar"><div><div className="table-title">All jobs</div><div className="table-subtitle">Live status of simulated automations</div></div><div className="toolbar-actions"><Button icon="filter">Filter</Button><Button icon="refresh" onClick={() => toast('Job statuses refreshed')}>Refresh</Button></div></div><div className="job-list">{jobs.map(([name, agent, state, trigger, last, progress]) => <div className="job-row" key={name}><div className="job-main"><div className="job-icon"><Icon name={state === 'Completed' ? 'check' : state === 'Scheduled' ? 'calendar' : 'spark'} /></div><div><div className="job-name">{name}</div><div className="job-agent">{agent}</div></div></div><div className="job-cell"><span>Trigger</span>{trigger}</div><div className="job-cell"><span>Last run</span>{last}</div><div className="job-status"><Status tone={state === 'Completed' || state === 'Active' ? 'green' : state === 'Running' ? 'blue' : 'gray'}>{state}</Status>{progress !== '—' && <div className="mini-progress"><i style={{ width: progress }} /></div>}</div><Button icon="chevron" variant="icon" title="View details" onClick={() => toast(`${name} details opened`)} /></div>)}</div></div></div>
}

function Documents({ toast }: { toast: (text: string) => void }) {
  const [files, setFiles] = useState([
    ['NZTA_Tender_2026.pdf', '4.8 MB', 'Processed'],
    ['Distributor_Sales_Q3.xlsx', '2.1 MB', 'Processing'],
    ['Smartstud_Quotation_1042.pdf', '860 KB', 'Completed'],
  ])
  const addFiles = (list: FileList | null) => {
    if (!list?.length) return
    setFiles((current) => [...current, ...Array.from(list).map((file) => [file.name, `${(file.size / 1024 / 1024).toFixed(1)} MB`, 'Processing'])])
    toast(`${list.length} document${list.length > 1 ? 's' : ''} added to the processing queue`)
  }
  return <div className="content-page page-scroll"><PageHeader title="Document ingestion" subtitle="Upload and process business documents for AI-powered search and analysis." /><div className="document-layout"><div className="table-card upload-card"><label className="drop-zone" onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); addFiles(e.dataTransfer.files) }}><input type="file" multiple accept=".pdf,.xlsx,.xls,.csv,.docx" onChange={(e) => addFiles(e.target.files)} /><div className="upload-symbol"><Icon name="upload" size={26} /></div><div className="drop-title">Drop business documents here</div><div className="drop-copy">Tender PDFs, sales spreadsheets, quotations, and other records</div><span className="btn btn-primary">Browse files</span><div className="drop-meta">PDF, XLSX, XLS, CSV, DOCX · Maximum 50 MB</div></label><div className="queue-header"><div><div className="table-title">Processing queue</div><div className="table-subtitle">{files.length} files · Simulated processing</div></div></div><div className="file-list">{files.map(([name, size, state], index) => <div className="file-row" key={`${name}-${index}`}><div className="file-icon"><Icon name="file" /></div><div className="file-main"><div className="file-name">{name}</div><div className="file-meta">{size} · Added today</div>{state === 'Processing' && <div className="file-progress"><i /></div>}</div><Status tone={state === 'Processing' ? 'blue' : 'green'}>{state}</Status><Button icon="eye" variant="icon" title="View extracted data" onClick={() => toast(`Extracted data preview opened for ${name}`)} /></div>)}</div></div><div className="table-card extraction-preview"><div className="preview-graphic"><Icon name="spark" size={30} /></div><div className="table-title">AI-ready knowledge</div><div className="preview-copy">Processed files become searchable in Street Smart AI and are linked to relevant business records.</div><div className="preview-stat"><span>Documents indexed</span><strong>1,284</strong></div><div className="preview-stat"><span>Extracted records</span><strong>12,480</strong></div><div className="preview-stat"><span>Last processed</span><strong>10 min ago</strong></div><Button icon="search" onClick={() => toast('Document search opened')}>Search documents</Button></div></div></div>
}

function DataExplorer({ toast }: { toast: (text: string) => void }) {
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<typeof tenders[number] | null>(null)
  const filtered = tenders.filter((item) => `${item.name} ${item.agency} ${item.country}`.toLowerCase().includes(search.toLowerCase()))
  return <div className="data-page"><PageHeader title="Database explorer" subtitle="Browse indexed operational records and source datasets." action={<Button icon="download" onClick={() => toast('Tender dataset exported')}>Export</Button>} /><div className="database-workspace"><aside className="catalog"><div className="catalog-title">Data catalog</div><Input placeholder="Search datasets" /><div className="tree"><div className="tree-group active"><div><Icon name="database" />Tenders 2026</div><span>1,248</span></div>{['Active tenders', 'Submitted tenders', 'Won tenders', 'Lost tenders'].map((item) => <button key={item} onClick={() => toast(`${item} dataset selected`)}>{item}<span>{Math.floor(Math.random() * 300) + 20}</span></button>)}<div className="tree-group"><div><Icon name="chart" />Distributor sales</div><span>8,420</span></div><div className="tree-group"><div><Icon name="grid" />Product catalogue</div><span>64</span></div><div className="tree-group"><div><Icon name="file" />Past quotations</div><span>2,748</span></div></div></aside><div className="dataset"><div className="dataset-header"><div><div className="table-title">Tenders 2026</div><div className="table-subtitle">Government infrastructure opportunities · Updated 10 minutes ago</div></div><Status tone="green">Connected</Status></div><div className="data-toolbar"><div className="search-field"><Icon name="search" /><Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search records..." /></div><Button icon="filter" onClick={() => toast('Filters opened')}>Filters</Button><Button icon="refresh" variant="icon" title="Refresh" onClick={() => toast('Records refreshed')} /></div><div className="table-scroll"><table><thead><tr>{['Tender ID', 'Tender name', 'Agency', 'Country', 'Closing date', 'Estimated value', 'Status'].map((head) => <th key={head}>{head}</th>)}</tr></thead><tbody>{filtered.map((item) => <tr key={item.id} onClick={() => setSelected(item)}><td className="id-cell">{item.id}</td><td className="name-cell">{item.name}</td><td>{item.agency}</td><td>{item.country}</td><td>{item.date}</td><td>{item.value}</td><td><Status tone={item.status === 'Won' ? 'green' : item.status === 'Pending' ? 'amber' : 'blue'}>{item.status}</Status></td></tr>)}</tbody></table></div><div className="table-footer"><span>Showing 1–{filtered.length} of 1,248 records</span><div><Button variant="icon" icon="chevron" title="Previous page" /><span>Page 1 of 125</span><Button variant="icon" icon="chevron" title="Next page" onClick={() => toast('Page 2 loaded')} /></div></div></div></div>{selected && <div className="drawer-backdrop" onClick={() => setSelected(null)}><aside className="record-drawer" onClick={(e) => e.stopPropagation()}><div className="drawer-header"><div><div className="eyebrow">{selected.id}</div><div className="drawer-title">{selected.name}</div></div><Button icon="close" variant="icon" title="Close" onClick={() => setSelected(null)} /></div><Status tone="blue">{selected.status}</Status><div className="drawer-section"><div className="drawer-label">Opportunity overview</div>{[['Government agency', selected.agency], ['Country', selected.country], ['Estimated value', selected.value], ['Submission deadline', selected.date], ['Product category', selected.product], ['Assigned distributor', 'RoadTech New Zealand']].map(([label, value]) => <div className="detail-row" key={label}><span>{label}</span><strong>{value}</strong></div>)}</div><div className="drawer-section"><div className="drawer-label">Summary</div><p>Supply and commissioning of intelligent LED road-safety markers across priority corridors, including installation guidance and warranty support.</p></div><div className="drawer-actions"><Button variant="primary" icon="spark" onClick={() => toast('AI context created for this tender')}>Ask AI about this tender</Button><Button icon="file" onClick={() => toast('Related documents opened')}>View documents</Button></div></aside></div>}</div>
}

function Reports({ toast }: { toast: (text: string) => void }) {
  const bars = [46, 62, 54, 78, 68, 86, 72, 92]
  return <div className="content-page page-scroll"><PageHeader title="Tender reports" subtitle="AI-generated analytics grounded in your tender pipeline." action={<><Button icon="calendar">Last 12 months</Button><Button icon="download" onClick={() => toast('Report exported as PDF')}>Export</Button></>} /><div className="report-kpis">{[['1,248', 'Total tenders', '+8.4% YoY'], ['NZD 8.42M', 'Active pipeline', '+12.1%'], ['34.8%', 'Success rate', '+3.2 pts'], ['42', 'Closing this month', '8 high priority']].map(([value, label, change]) => <div className="report-kpi" key={label}><div className="kpi-label">{label}</div><div className="report-value">{value}</div><div className="positive">{change}</div></div>)}</div><div className="report-grid"><div className="table-card chart-card"><div className="section-heading"><div><div className="table-title">Monthly tender performance</div><div className="table-subtitle">Submitted opportunity value, NZD thousands</div></div><Button icon="more" variant="icon" title="Chart options" /></div><div className="bar-chart">{bars.map((height, index) => <div className="bar-column" key={index}><div className="bar-value">{[420, 580, 490, 760, 640, 920, 710, 1040][index]}</div><div className="bar" style={{ height: `${height}%` }} /><span>{['Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'][index]}</span></div>)}</div></div><div className="table-card country-card"><div className="table-title">Pipeline by country</div><div className="table-subtitle">Share of active opportunity value</div>{[['New Zealand', '42%', 42], ['Australia', '27%', 27], ['Asia Pacific', '18%', 18], ['Europe', '13%', 13]].map(([name, value, width]) => <div className="country-row" key={name as string}><div><span>{name}</span><strong>{value}</strong></div><div className="country-track"><i style={{ width: `${width}%` }} /></div></div>)}</div></div><div className="section-heading report-library-title"><div><div className="section-title">Pinned reports</div><div className="section-subtitle">Frequently used reporting workspaces</div></div></div><div className="report-library">{['Tender Pipeline Overview', 'Tender Win/Loss Analysis', 'Tender Value by Country', 'Monthly Tender Submissions', 'Distributor Sales Performance', 'Product Sales Mix', 'Quotation Conversion', 'Upcoming Tender Deadlines'].map((name, index) => <button className="report-card" key={name} onClick={() => toast(`${name} report opened`)}><div className="report-icon"><Icon name={index % 2 ? 'chart' : 'pulse'} /></div><div><div className="report-name">{name}</div><div className="report-updated">Updated {index < 2 ? 'today' : `${index} days ago`}</div></div><Icon name="chevron" /></button>)}</div></div>
}

function SimplePage({ type, toast }: { type: 'connections' | 'status' | 'alerts' | 'conversations'; toast: (text: string) => void }) {
  if (type === 'connections') return <div className="content-page page-scroll"><PageHeader title="Database connections" subtitle="Manage the data sources available to Street Smart AI." action={<Button icon="plus" variant="primary" onClick={() => toast('Connection setup opened')}>Add connection</Button>} /><div className="connection-grid">{[['Tender Operations DB', 'PostgreSQL', '12,480 records'], ['Distributor Sales Warehouse', 'Microsoft SQL Server', '86,214 records'], ['Product Catalogue', 'MySQL', '64 products']].map(([name, db, records]) => <div className="connection-card" key={name}><div className="connection-top"><div className="connection-icon"><Icon name="database" /></div><Status tone="green">Connected</Status></div><div className="space-title">{name}</div><div className="space-desc">{db} · host••••.internal</div><div className="connection-meta"><span>Last sync<strong>10 minutes ago</strong></span><span>Indexed<strong>{records}</strong></span></div><div className="action-row"><Button icon="pulse" onClick={() => toast(`${name} connection test successful`)}>Test connection</Button><Button icon="more" variant="icon" title="Connection options" /></div></div>)}</div></div>
  if (type === 'status') return <div className="content-page page-scroll"><PageHeader title="System status" subtitle="Operational health across your simulated business services." /><div className="health-banner"><div className="health-check"><Icon name="check" size={28} /></div><div><div className="health-title">All core services are operational</div><div className="health-copy">Last checked just now · 99.98% uptime over the past 30 days</div></div><Button icon="refresh" onClick={() => toast('System health refreshed')}>Refresh</Button></div><div className="service-list">{[['Database availability', 'Operational', '99.99%', '34 ms'], ['Document processing', 'Operational', '99.97%', '12 queued'], ['AI assistant service', 'Operational', '99.99%', '780 ms'], ['API connectivity', 'Degraded', '98.84%', '2 warnings'], ['Storage utilization', 'Operational', '99.99%', '62% used']].map(([name, state, uptime, detail]) => <div className="service-row" key={name}><div className="service-name"><span className={state === 'Degraded' ? 'indicator warning' : 'indicator'} />{name}</div><Status tone={state === 'Degraded' ? 'amber' : 'green'}>{state}</Status><div className="job-cell"><span>30-day uptime</span>{uptime}</div><div className="job-cell"><span>Current</span>{detail}</div><Button icon="chevron" variant="icon" title="View service details" onClick={() => toast(`${name} details opened`)} /></div>)}</div></div>
  if (type === 'alerts') return <div className="content-page page-scroll"><PageHeader title="Alerts" subtitle="Review system and business events that need attention." /><div className="alert-list">{[['High', 'Tender deadline in 5 days', 'Auckland Smart Road Upgrade requires final compliance review.', 'Tender pipeline', '12 minutes ago'], ['Medium', 'API sync delayed', 'Distributor Sales Warehouse synchronization is running 18 minutes behind.', 'Data connections', '42 minutes ago'], ['Resolved', 'Document extraction retried', 'A scanned appendix was successfully processed on the second attempt.', 'Document ingestion', 'Yesterday']].map(([severity, title, desc, module, time]) => <div className="alert-card" key={title}><div className={`alert-severity ${severity.toLowerCase()}`}><Icon name={severity === 'Resolved' ? 'check' : 'warning'} /></div><div className="alert-body"><div className="alert-top"><div className="alert-title">{title}</div><Status tone={severity === 'High' ? 'red' : severity === 'Medium' ? 'amber' : 'green'}>{severity}</Status></div><div className="alert-desc">{desc}</div><div className="alert-meta">{module} · {time}</div></div>{severity !== 'Resolved' ? <Button onClick={() => toast(`"${title}" marked as resolved`)}>Mark resolved</Button> : <Button variant="ghost" onClick={() => toast('Alert detail opened')}>View detail</Button>}</div>)}</div></div>
  return <div className="content-page page-scroll"><PageHeader title="Conversations" subtitle="Continue recent work with Street Smart AI." action={<Button icon="plus" variant="primary" onClick={() => toast('New conversation started')}>New conversation</Button>} /><div className="conversation-list">{[['Tender priorities for New Zealand', 'Based on the current pipeline, I recommend prioritizing...', '10 min ago'], ['Q3 distributor sales comparison', 'Australia grew 14% while New Zealand remained...', 'Yesterday'], ['Smartstud product growth', 'The SRS-8 solar road stud leads with 22% growth...', 'Monday'], ['Quotation approval queue', 'Five quotations are awaiting approval, totaling...', '18 Nov']].map(([title, copy, date]) => <button className="conversation-row" key={title} onClick={() => toast(`${title} opened`)}><div className="activity-icon"><Icon name="chat" /></div><div><div className="conversation-row-title">{title}</div><div className="conversation-row-copy">{copy}</div></div><span>{date}</span><Icon name="chevron" /></button>)}</div></div>
}

export default function App() {
  const [page, setPage] = useState<Page>('discover')
  const [collapsed, setCollapsed] = useState(false)
  const [mobileNav, setMobileNav] = useState(false)
  const [initialPrompt, setInitialPrompt] = useState('')
  const [toastText, setToastText] = useState('')
  const [globalSearch, setGlobalSearch] = useState('')
  const [notifications, setNotifications] = useState(false)
  const title = useMemo(() => navGroups.flatMap((g) => g.items).find((item) => item.id === page)?.label || 'Discover', [page])
  const toast = (text: string) => { setToastText(text); window.setTimeout(() => setToastText(''), 2600) }
  const go = (target: Page) => { setPage(target); setMobileNav(false) }
  const openConversation = (prompt: string) => { setInitialPrompt(prompt); go('conversation') }

  const content = page === 'discover' ? <Discover openConversation={openConversation} go={go} />
    : page === 'conversation' ? <Conversation initialPrompt={initialPrompt} go={go} toast={toast} />
    : page === 'spaces' ? <Spaces toast={toast} />
    : page === 'jobs' ? <Jobs toast={toast} />
    : page === 'documents' ? <Documents toast={toast} />
    : page === 'data' ? <DataExplorer toast={toast} />
    : page === 'reports' ? <Reports toast={toast} />
    : <SimplePage type={page as 'connections' | 'status' | 'alerts' | 'conversations'} toast={toast} />

  return <div className="app">
    <header className="topbar">
      <div className="brand"><Button icon="menu" variant="icon" className="mobile-menu" title="Open navigation" onClick={() => setMobileNav(!mobileNav)} /><button className="brand-button" onClick={() => go('discover')}><span className="brand-mark">S</span><span className="brand-words"><strong>Street Smart Cockpit</strong><small>AI BUSINESS OPERATIONS</small></span></button></div>
      <div className="global-search"><Icon name="search" /><Input value={globalSearch} onChange={(e) => setGlobalSearch(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter' && globalSearch.trim()) { openConversation(globalSearch); setGlobalSearch('') } }} placeholder="Search conversations, tenders, distributors, documents..." /><span>⌘ K</span></div>
      <div className="top-actions"><div className="environment"><span /> Simulation</div><div className="notification-wrap"><Button icon="bell" variant="icon" title="Notifications" onClick={() => setNotifications(!notifications)} /><i className="notification-dot" />{notifications && <div className="notification-popover"><div className="popover-title">Notifications</div><div className="notification-item"><span className="indicator warning" /><div><strong>Tender deadline approaching</strong><small>Auckland closes in 5 days</small></div></div><div className="notification-item"><span className="indicator" /><div><strong>Report ready</strong><small>Weekly sales summary generated</small></div></div></div>}</div><button className="profile" onClick={() => toast('Profile menu opened')}><span>IN</span><div><strong>Isaac Ngatai</strong><small>Operations</small></div><Icon name="chevron" size={14} /></button></div>
    </header>
    <div className="app-body">
      <aside className={`sidebar ${collapsed ? 'collapsed' : ''} ${mobileNav ? 'mobile-open' : ''}`}>
        <div className="nav-scroll">{navGroups.map((group) => <div className="nav-group" key={group.label}><div className="nav-label">{group.label}</div>{group.items.map((item) => <button key={item.id} title={collapsed ? item.label : undefined} className={`nav-item ${page === item.id ? 'active' : ''}`} onClick={() => go(item.id)}><Icon name={item.icon} /><span>{item.label}</span>{item.id === 'alerts' && <b>2</b>}</button>)}</div>)}</div>
        <div className="sidebar-footer"><button className="nav-item" onClick={() => toast('Help center opened')}><Icon name="help" /><span>Help & support</span></button><button className="nav-item" onClick={() => toast('Settings opened')}><Icon name="settings" /><span>Settings</span></button><button className="nav-item collapse-action" onClick={() => setCollapsed(!collapsed)}><Icon name="chevron" /><span>Collapse sidebar</span></button></div>
      </aside>
      <main className="main"><div className="mobile-context">{title}</div>{content}</main>
    </div>
    {toastText && <div className="toast"><span><Icon name="check" /></span>{toastText}</div>}
  </div>
}
